//
//  PkgByCategoriaModel.swift
//  TurismoSV_app
//
//  Created by HenryGuzman on 6/5/23.
//  Copyright © 2023 HenryGuzman. All rights reserved.
//

import Foundation

class PkgByCategoriaModel{
    
    public struct Model {
        let IdCategoria:String?
    }
}
