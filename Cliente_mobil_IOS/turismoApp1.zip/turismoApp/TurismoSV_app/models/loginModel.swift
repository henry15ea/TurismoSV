//
//  loginModel.swift
//  TurismoSV_app
//
//  Created by HenryGuzman on 5/29/23.
//  Copyright © 2023 HenryGuzman. All rights reserved.
//

import Foundation

class LoginModel{
    
    public struct UserLogin {
        let username:String?
        let password:String?
    }
}
