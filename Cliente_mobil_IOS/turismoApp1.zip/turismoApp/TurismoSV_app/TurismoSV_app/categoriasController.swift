//
//  categoriasController.swift
//  TurismoSV_app
//
//  Created by HenryGuzman on 6/1/23.
//  Copyright © 2023 HenryGuzman. All rights reserved.
//

import UIKit

class categoriasController: UIBarItem {

}
