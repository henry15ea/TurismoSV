//
//  DetalleViewController.swift
//  TurismoSV_app
//
//  Created by ronald on 8/6/23.
//  Copyright © 2023 HenryGuzman. All rights reserved.
//

import UIKit

class DetalleViewController: UIViewController {
    
    var nom:String?;
    var des:String?
    var direccion:String?
    var imgurl:String?
    var precio:Double=0
    var cupos_disp:String?
    var cuposllenos:String?
    var fechainicial:String?
    var fechafinal:String?

    
    
    
    @IBOutlet weak var imgview: UIImageView!
    
    @IBOutlet weak var txt_nombre: UILabel!
    
    @IBOutlet weak var txt_des: UILabel!
    
    @IBOutlet weak var txt_dir: UILabel!
    
    @IBOutlet weak var txt_precio: UILabel!
    
    @IBOutlet weak var txt_cupos: UILabel!
    
    @IBOutlet weak var txt_cuposllenos: UILabel!
    
    @IBOutlet weak var txt_fechin: UILabel!
    
    @IBOutlet weak var txt_fechfin: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imgview.image=cls_ImagenUrl.fn_LoadImageUrl(from: imgurl!, defaultImage: "icono-rutas")
        txt_nombre.text=nom
        txt_des.text=des
        txt_dir.text=direccion
        txt_precio.text="\(precio)"
        txt_cupos.text=cupos_disp
        txt_cuposllenos.text=cuposllenos
        txt_fechin.text=fechainicial
        txt_fechfin.text=fechafinal
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func btnVolver(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    


}
